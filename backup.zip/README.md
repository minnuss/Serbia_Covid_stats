# Serbia Covid stats

TITLE - Serbia Covid stats

About - Covid stats updated daily with country search input

TECHNOLOGIES USED:

- HTML5
- Google Fonts
- Sass - Flexbox, Media Queries
- JavaScript - API
- Git
